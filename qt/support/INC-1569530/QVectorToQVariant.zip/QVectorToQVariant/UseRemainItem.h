#ifndef USEREMAINITEM_H
#define USEREMAINITEM_H

struct UseRemainItem {
  int toolIdx;
  int serialNo;
  int remainCnt;
  int total;
};

#endif // USEREMAINITEM_H
